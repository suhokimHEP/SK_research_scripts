#include <iostream>
#include "TString.h"
#include "TH1F.h"
#include "TCanvas.h"
#include "THStack.h"
#include "TLegend.h"
#include "TPad.h"
#include "TStyle.h"
#include "TText.h"
#include "TFile.h"
#include <stdio.h>
#include <cstdlib> /* mkdir */

#include <stdlib.h>     /* getenv */
#include <cmath>     /* getenv */
using namespace std;

void Sig_model(TString region, Bool_t dolog, Bool_t HIP, Bool_t doctau, Bool_t useEOS, TString description)
{
// // Draw signal as lines
Bool_t drawSignal = kTRUE; //kTRUE; //kFALSE
//Bool_t drawWHSignal = kTRUE;
// Bool_t drawRatio = kTRUE;

 // Setup running configuration: IO, naming, SFs, ..
 /////////////////////////////////////////////////////

 bool drawData = true;
 bool useAlt = false; 
 bool doUncPlots = true;

 TString outpath = TString("../plots/");
 TString aversion = TString(getenv("aversion"));
 TString nversion = TString(getenv("nversion"));
 TString depot = TString(getenv("depot2"));
 TString inpath  = TString("../roots/");
 if(useEOS){
  inpath = "root://cmsxrootd.fnal.gov/"+depot+"/"+nversion+"/analyzed/"; 
}

 inpath = inpath+aversion+"/";
 outpath = outpath+aversion+"/"+region+"/";

 TString extraname = "";
 if(HIP){
  extraname+="_BCDEF";
  outpath = outpath+"BCDEF/";
 }
 if(!HIP){
  //outpath = outpath+"GH/";
  //extraname+="_GH";
 }

 // lumi scaling by era
 Float_t MCSF = 1.;
 Float_t lumiBCDEF = 19691. ;
 Float_t lumiGH = 16226.5 ;

// if(HIP){ MCSF=lumiBCDEF/10000.; }
// else{ MCSF=lumiGH/10000.; }
 
 //TString extraname = "";
 if(dolog){
  extraname+="_log";
  outpath = outpath+"log/";
 }

 TString mdcommand = (TString)"mkdir -p "+outpath.Data();
 const int dir_err = system(mdcommand);
 TString mdcommandtable = (TString)"mkdir -p "+outpath.Data()+"tables/";
 const int dir_err2 = system(mdcommandtable);

 std::vector<TString> MSbins;
 MSbins.push_back("Sig_MS-55_ctauS-100_"); 










 std::vector<TString> uncbins;
 uncbins.clear();
 uncbins.push_back(""             ); 

 int loopEnd;
 if (doUncPlots) loopEnd=uncbins.size(); else loopEnd=1;
 std::vector<TString> variables;
 variables.clear();

variables.push_back("nSelectedAODCaloJetTag");
//variables.push_back("nSelectedAODCaloJetTag_unit");
//variables.push_back("nSelectedAODCaloJetTagSB1");
//variables.push_back("nSelectedAODCaloJetTagSB2");
//variables.push_back("nSelectedAODCaloJetTagSB3");
//variables.push_back("nSelectedAODCaloJetTagSB4");
//variables.push_back("nSelectedAODCaloJetTagSB5");
//variables.push_back("nSelectedAODCaloJetTagSB6");
//variables.push_back("nSelectedAODCaloJetTagSB7");

 // canvas and text attributes

 // initialize histogram files
 TFile* file_DY_2016_M50     ;
 TFile* file_DY_2016_mad_M50     ;
 TFile* file_DY_2017_M50     ;
 TFile* file_DY_2018_M50     ;
 TFile* file_DY_2018_mad_M50     ;
 TFile* file_DY_2018_M50_JEC     ;
 TFile* file_DY_2018_mad_M50_JEC     ;
 TFile* file_DY_2018_M50_JEC_Zpt     ;
 TFile* file_DY_2018_2J_JEC     ;
 TFile* file_ZH_2016_M50     ;
 TFile* file_ZH_2016_mad_M50     ;
 TFile* file_ZH_2017_M50     ;
 TFile* file_ZH_2018_M50     ;
 TFile* file_ZH_2018_mad_M50     ;
 TFile* file_ZH_2018_M50_JEC     ;
 TFile* file_ZH_2018_mad_M50_JEC     ;
 TFile* file_ZH_2018_M50_JEC_Zpt     ;
 TFile* file_ZH_2018_2J_JEC     ;


 // initialize histos
 TH1F*  h_DY_2016_M50                           ;
 TH1F*  h_DY_2016_mad_M50                           ;
 TH1F*  h_DY_2016_madamc_M50                           ;
 TH1F*  h_DY_2017_M50                           ;
 TH1F*  h_DY_2018_M50                           ;
 TH1F*  h_DY_2018_mad_M50                           ;
 TH1F*  h_DY_2018_madamc_M50                           ;
 TH1F*  h_DY_2018_M50_JEC                           ;
 TH1F*  h_DY_2018_mad_M50_JEC                           ;
 TH1F*  h_DY_2018_madamc_M50_JEC                           ;
 TH1F*  h_DY_2018_M50_JEC_Zpt                           ;
 TH1F*  h_DY_2018_2J_JEC                           ;
 TH1F*  h_DY_hadd	                          ;
 TH1F*  h_DY_hadd_madamc	                          ;


 TH1F*  h_ZH_2016_M50                           ;
 TH1F*  h_ZH_2016_mad_M50                           ;
 TH1F*  h_ZH_2016_madamc_M50                           ;
 TH1F*  h_ZH_2017_M50                           ;
 TH1F*  h_ZH_2018_M50                           ;
 TH1F*  h_ZH_2018_mad_M50                           ;
 TH1F*  h_ZH_2018_madamc_M50                           ;
 TH1F*  h_ZH_2018_M50_JEC                           ;
 TH1F*  h_ZH_2018_mad_M50_JEC                           ;
 TH1F*  h_ZH_2018_madamc_M50_JEC                           ;
 TH1F*  h_ZH_2018_M50_JEC_Zpt                           ;
 TH1F*  h_ZH_2018_2J_JEC                           ;
 TH1F*  h_ZH_hadd	                          ;
 TH1F*  h_ZH_hadd_madamc	                          ;

 TH1F*  h_TF_2016_M50                           ;
 TH1F*  h_TF_2016_mad_M50                           ;
 TH1F*  h_TF_2016_madamc_M50                           ;
 TH1F*  h_TF_2017_M50                           ;
 TH1F*  h_TF_2018_M50                           ;
 TH1F*  h_TF_2018_mad_M50                           ;
 TH1F*  h_TF_2018_madamc_M50                           ;
 TH1F*  h_TF_2018_M50_JEC                           ;
 TH1F*  h_TF_2018_mad_M50_JEC                           ;
 TH1F*  h_TF_2018_madamc_M50_JEC                           ;
 TH1F*  h_TF_2018_M50_JEC_Zpt                           ;
 TH1F*  h_TF_2018_2J_JEC                           ;
 TH1F*  h_TF_hadd	                          ;
 TH1F*  h_TF_hadd_madamc	                          ;


 // (combined) histos to be made

 // load histogram files
 file_DY_2016_mad_M50                    = TFile::Open( "/uscms/home/skim2/nobackup/LLDJ_slc7_530_CMSSW_8_0_26_patch1/src/LLDJstandalones/roots/NoJEC_25/mad_DYJetsToLL_M-50_"+region+"DY_histograms.root"                 ) ;
 file_DY_2016_M50                    = TFile::Open( "/uscms/home/skim2/nobackup/LLDJ_slc7_530_CMSSW_8_0_26_patch1/src/LLDJstandalones/roots/NoJEC_25/DYJetsToLL_M-50_"+region+"DY_histograms.root"                 ) ;
 file_DY_2017_M50                    = TFile::Open( "/uscms/home/skim2/nobackup/2017-LLDJ_slc7_630_CMSSW_9_4_10/src/2017lldj/roots/NoJEC_25/DYJetsToLL_M-50_"+region+"DY_histograms.root"                 ) ;
 file_DY_2018_M50                    = TFile::Open( "/uscms/home/skim2/nobackup/2018-LLDJ_slc7_700_CMSSW_10_2_5/src/2018lldj/roots/NoJEC_25/DYJetsToLL_M-50_"+region+"DY_histograms.root"                 ) ;
 file_DY_2018_mad_M50                    = TFile::Open( "/uscms/home/skim2/nobackup/2018-LLDJ_slc7_700_CMSSW_10_2_5/src/2018lldj/roots/NoJEC_25/mad_DYJetsToLL_M-50_"+region+"DY_histograms.root"                 ) ;
 file_DY_2018_M50_JEC                    = TFile::Open( "/uscms/home/skim2/nobackup/2018-LLDJ_slc7_700_CMSSW_10_2_5/src/2018lldj/roots/JEC/DYJetsToLL_M-50_"+region+"DY_histograms.root"                 ) ;
 file_DY_2018_mad_M50_JEC                    = TFile::Open( "/uscms/home/skim2/nobackup/2018-LLDJ_slc7_700_CMSSW_10_2_5/src/2018lldj/roots/JEC/mad_DYJetsToLL_M-50_"+region+"DY_histograms.root"                 ) ;
// file_DY_2018_M50_JEC_Zpt                    = TFile::Open( "/uscms/home/skim2/nobackup/2018-LLDJ_slc7_700_CMSSW_10_2_5/src/2018lldj/roots/JEC_Zpt10GeV/DYJetsToLL_M-50_"+region+"DY_histograms.root"                 ) ;
 file_DY_2018_2J_JEC                    = TFile::Open( "/uscms/home/skim2/nobackup/2018-LLDJ_slc7_700_CMSSW_10_2_5/src/2018lldj/roots/JEC/DYJetsToLL_2J_"+region+"DY_histograms.root"                 ) ;
 file_ZH_2016_M50                    = TFile::Open( "/uscms/home/skim2/nobackup/LLDJ_slc7_530_CMSSW_8_0_26_patch1/src/LLDJstandalones/roots/NoJEC_25/DYJetsToLL_M-50_"+region+"ZH_histograms.root"                 ) ;
 file_ZH_2016_mad_M50                    = TFile::Open( "/uscms/home/skim2/nobackup/LLDJ_slc7_530_CMSSW_8_0_26_patch1/src/LLDJstandalones/roots/NoJEC_25/mad_DYJetsToLL_M-50_"+region+"ZH_histograms.root"                 ) ;
 file_ZH_2017_M50                    = TFile::Open( "/uscms/home/skim2/nobackup/2017-LLDJ_slc7_630_CMSSW_9_4_10/src/2017lldj/roots/NoJEC_25/DYJetsToLL_M-50_"+region+"ZH_histograms.root"                 ) ;
 file_ZH_2018_M50                    = TFile::Open( "/uscms/home/skim2/nobackup/2018-LLDJ_slc7_700_CMSSW_10_2_5/src/2018lldj/roots/NoJEC_25/DYJetsToLL_M-50_"+region+"ZH_histograms.root"                 ) ;
 file_ZH_2018_mad_M50                    = TFile::Open( "/uscms/home/skim2/nobackup/2018-LLDJ_slc7_700_CMSSW_10_2_5/src/2018lldj/roots/NoJEC_25/mad_DYJetsToLL_M-50_"+region+"ZH_histograms.root"                 ) ;
 file_ZH_2018_M50_JEC                    = TFile::Open( "/uscms/home/skim2/nobackup/2018-LLDJ_slc7_700_CMSSW_10_2_5/src/2018lldj/roots/JEC/DYJetsToLL_M-50_"+region+"ZH_histograms.root"                 ) ;
 file_ZH_2018_mad_M50_JEC                    = TFile::Open( "/uscms/home/skim2/nobackup/2018-LLDJ_slc7_700_CMSSW_10_2_5/src/2018lldj/roots/JEC/mad_DYJetsToLL_M-50_"+region+"ZH_histograms.root"                 ) ;
// file_ZH_2018_M50_JEC_Zpt                    = TFile::Open( "/uscms/home/skim2/nobackup/2018-LLDJ_slc7_700_CMSSW_10_2_5/src/2018lldj/roots/JEC_Zpt10GeV/DYJetsToLL_M-50_"+region+"ZH_histograms.root"                 ) ;
 file_ZH_2018_2J_JEC                    = TFile::Open( "/uscms/home/skim2/nobackup/2018-LLDJ_slc7_700_CMSSW_10_2_5/src/2018lldj/roots/JEC/DYJetsToLL_2J_"+region+"ZH_histograms.root"                 ) ;

//for(unsigned int k=0; k<MSbins.size(); ++k){
// //file_Sig                    = TFile::Open( inpath + "Sig_MS-55_ctauS-100_"+region+".root"                 ) ;
// TString MSsample = MSbins[k];
// //file_Sig                    = TFile::Open( inpath + MSsample+region+".root"                 ) ;
// file_Sig                = TFile::Open( inpath + "DYJetsToLL_M-50_"+region+"_histograms.root"             ) ; 


 // Start looping over variables, systematic uncertainty bins, make plots / tables / root files
  for(unsigned int j=0; j<variables.size(); ++j){
   TString variable = variables[j];

   for(unsigned int tt=0; tt<loopEnd; ++tt){
    TString uncbin = uncbins[tt];
    //Override drawData for nTag signal region
    if(region.Contains("ZH") && 
       (variable=="nSelectedAODCaloJetTag" || 
	variable.Contains("Log10IPSig") || 
	variable.Contains("Log10TrackAngle") || 
	variable.Contains("AlphaMax")) ) {
      drawData=false;
    }
    if(variable.Contains("Raw")){
     drawData=false;
    }
    if( variable.Contains("NMinus")   ||
	variable.Contains("Onecut")   ||               
	variable.Contains("Cutflow") ) {
     dolog=true;
    }

    Bool_t domaketable = kTRUE;
    if(j==0){
     domaketable = kTRUE;
    }
     TString varname = region+"_"+variable;

     printf("plotting  h_%s \n",varname.Data());

     TString outname = outpath+varname+extraname+uncbin; 
     TString fulllogname = outpath+"tables/full_"+varname+extraname+uncbin; 
     //cout << "logname: " << logname << endl;
     // get histograms from files
     //h_Sig_ZH10to50                        = (TH1F*)file_DY10to50                         ->Get("h_"+varname+uncbin)->Clone( "DY10to50"                        +uncbin ) ;
cout<<"where"<<endl;
    

     h_DY_2016_M50                          	= (TH1F*)file_DY_2016_M50->Get("h_"+region+"DY_"+variable)->Clone("h_DY_2016_M50"); 
     h_DY_2016_mad_M50                          	= (TH1F*)file_DY_2016_mad_M50->Get("h_"+region+"DY_"+variable)->Clone("h_DY_2016_mad_M50"); 
     h_DY_2017_M50                          	= (TH1F*)file_DY_2017_M50->Get("h_"+region+"DY_"+variable)->Clone("h_DY_2017_M50"); 
     h_DY_2018_M50                          	= (TH1F*)file_DY_2018_M50->Get("h_"+region+"DY_"+variable)->Clone("h_DY_2018_M50"); 
     h_DY_2018_mad_M50                          	= (TH1F*)file_DY_2018_mad_M50->Get("h_"+region+"DY_"+variable)->Clone("h_DY_2018_mad_M50"); 
     h_DY_2018_M50_JEC                          	= (TH1F*)file_DY_2018_M50_JEC->Get("h_"+region+"DY_"+variable)->Clone("h_DY_2018_M50_JEC"); 
     h_DY_2018_mad_M50_JEC                          	= (TH1F*)file_DY_2018_mad_M50_JEC->Get("h_"+region+"DY_"+variable)->Clone("h_DY_2018_mad_M50_JEC"); 
     //h_DY_2018_M50_JEC_Zpt                          	= (TH1F*)file_DY_2018_M50_JEC_Zpt->Get("h_"+region+"DY_"+variable)->Clone("h_DY_2018_M50_JEC_Zpt"); 
     h_DY_2018_2J_JEC                          	= (TH1F*)file_DY_2018_2J_JEC->Get("h_"+region+"DY_"+variable)->Clone("h_DY_2018_2J_JEC"); 

     h_ZH_2016_M50                          	= (TH1F*)file_ZH_2016_M50->Get("h_"+region+"ZH_"+variable)->Clone("h_ZH_2016_M50"); 
     h_ZH_2016_mad_M50                          	= (TH1F*)file_ZH_2016_mad_M50->Get("h_"+region+"ZH_"+variable)->Clone("h_ZH_2016_mad_M50"); 
     h_ZH_2017_M50                          	= (TH1F*)file_ZH_2017_M50->Get("h_"+region+"ZH_"+variable)->Clone("h_ZH_2017_M50"); 
     h_ZH_2018_M50                          	= (TH1F*)file_ZH_2018_M50->Get("h_"+region+"ZH_"+variable)->Clone("h_ZH_2018_M50"); 
     h_ZH_2018_mad_M50                          	= (TH1F*)file_ZH_2018_mad_M50->Get("h_"+region+"ZH_"+variable)->Clone("h_ZH_2018_mad_M50"); 
     h_ZH_2018_M50_JEC                          	= (TH1F*)file_ZH_2018_M50_JEC->Get("h_"+region+"ZH_"+variable)->Clone("h_ZH_2018_M50_JEC"); 
     h_ZH_2018_mad_M50_JEC                          	= (TH1F*)file_ZH_2018_mad_M50_JEC->Get("h_"+region+"ZH_"+variable)->Clone("h_ZH_2018_mad_M50_JEC"); 
     //h_ZH_2018_M50_JEC_Zpt                          	= (TH1F*)file_ZH_2018_M50_JEC_Zpt->Get("h_"+region+"ZH_"+variable)->Clone("h_ZH_2018_M50_JEC_Zpt"); 
     h_ZH_2018_2J_JEC                          	= (TH1F*)file_ZH_2018_2J_JEC->Get("h_"+region+"ZH_"+variable)->Clone("h_ZH_2018_2J_JEC"); 

    //cout<<h_DY_2018_M50_JEC_Zpt->GetBinContent(1)<<endl; 
    //cout<<h_ZH_2018_M50_JEC_Zpt->GetBinContent(1)<<endl; 

    if(!variable.Contains("unit")) 
     {bool scale = true;
      if(scale){ 
	fulllogname = fulllogname+"_scaleby"+description;
    h_DY_2016_M50->Scale(16.226/20.0);
    h_DY_2016_mad_M50->Scale(16.226/20.0);
    h_DY_2017_M50->Scale(.738*41.4/20.0);
    h_DY_2018_M50->Scale(.734*58.67/20.0);
    h_DY_2018_mad_M50->Scale(.734*58.67/20.0);
    h_DY_2018_M50_JEC->Scale(58.67/20.0);
    h_DY_2018_mad_M50_JEC->Scale(58.67/20.0);
    //h_DY_2018_M50_JEC_Zpt->Scale(58.67/20.0);
    h_DY_2018_2J_JEC->Scale(58.67/20.0);

    h_ZH_2016_M50->Scale(16.226/20.0);
    h_ZH_2016_mad_M50->Scale(16.226/20.0);
    h_ZH_2017_M50->Scale(.738*41.4/20.0);
    h_ZH_2018_M50->Scale(.734*58.67/20.0);
    h_ZH_2018_mad_M50->Scale(.734*58.67/20.0);
    h_ZH_2018_M50_JEC->Scale(58.67/20.0);
    h_ZH_2018_mad_M50_JEC->Scale(58.67/20.0);
    //h_ZH_2018_M50_JEC_Zpt->Scale(58.67/20.0);
    h_ZH_2018_2J_JEC->Scale(58.67/20.0);
	}
	}

    h_DY_hadd=(TH1F*)h_DY_2016_M50->Clone("h_DY_hadd");
    h_DY_hadd->Add(h_DY_2017_M50);	
    h_DY_hadd->Add(h_DY_2018_M50);	
    h_ZH_hadd=(TH1F*)h_ZH_2016_M50->Clone("h_ZH_hadd");
    h_ZH_hadd->Add(h_ZH_2017_M50);	
    h_ZH_hadd->Add(h_ZH_2018_M50);	
  


    h_DY_2016_madamc_M50=(TH1F*)h_DY_2016_M50->Clone("h_DY_hadd");
    h_DY_2016_madamc_M50->Scale(0.33); 
    h_DY_2018_madamc_M50=(TH1F*)h_DY_2018_M50->Clone("h_DY_hadd");
    h_DY_2018_madamc_M50->Scale(0.33); 
    h_ZH_2016_madamc_M50=(TH1F*)h_ZH_2016_M50->Clone("h_ZH_hadd");
    h_ZH_2016_madamc_M50->Scale(0.33); 
    h_ZH_2018_madamc_M50=(TH1F*)h_ZH_2018_M50->Clone("h_ZH_hadd");
    h_ZH_2018_madamc_M50->Scale(0.33); 




    TH1F* temp_DY_2016_mad_M50 = (TH1F*)h_DY_2016_mad_M50->Clone("");
    temp_DY_2016_mad_M50->Scale(0.67); 
    h_DY_2016_madamc_M50->Add(temp_DY_2016_mad_M50);
    TH1F* temp_DY_2018_mad_M50 = (TH1F*)h_DY_2018_mad_M50->Clone("");
    temp_DY_2018_mad_M50->Scale(0.67); 
    h_DY_2018_madamc_M50->Add(temp_DY_2018_mad_M50);
    TH1F* temp_ZH_2016_mad_M50 = (TH1F*)h_ZH_2016_mad_M50->Clone("");
    temp_ZH_2016_mad_M50->Scale(0.67); 
    h_ZH_2016_madamc_M50->Add(temp_ZH_2016_mad_M50);
    TH1F* temp_ZH_2018_mad_M50 = (TH1F*)h_ZH_2018_mad_M50->Clone("");
    temp_ZH_2018_mad_M50->Scale(0.67); 
    h_ZH_2018_madamc_M50->Add(temp_ZH_2018_mad_M50);




    h_DY_hadd_madamc = (TH1F*)h_DY_2016_madamc_M50->Clone("h_DY_hadd_madamc"); 
    h_DY_hadd_madamc->Add(h_DY_2017_M50);  
    h_DY_hadd_madamc->Add(h_DY_2018_madamc_M50);  
    h_ZH_hadd_madamc = (TH1F*)h_ZH_2016_madamc_M50->Clone("h_ZH_hadd_madamc"); 
    h_ZH_hadd_madamc->Add(h_ZH_2017_M50);  
    h_ZH_hadd_madamc->Add(h_ZH_2018_madamc_M50);  

    //cout<<h_DY_2018_M50_JEC_Zpt->GetBinContent(1)<<endl; 
    //cout<<h_ZH_2018_M50_JEC_Zpt->GetBinContent(1)<<endl; 

	


     h_TF_2016_M50                          	= (TH1F*)file_ZH_2016_M50->Get("h_"+region+"ZH_"+variable)->Clone("h_TF_2016_M50"); 
     h_TF_2016_mad_M50                          	= (TH1F*)file_ZH_2016_mad_M50->Get("h_"+region+"ZH_"+variable)->Clone("h_TF_2016_mad_M50"); 
     h_TF_2017_M50                          	= (TH1F*)file_ZH_2017_M50->Get("h_"+region+"ZH_"+variable)->Clone("h_TF_2017_M50"); 
     h_TF_2018_M50                          	= (TH1F*)file_ZH_2018_M50->Get("h_"+region+"ZH_"+variable)->Clone("h_TF_2018_M50"); 
     h_TF_2018_mad_M50                          	= (TH1F*)file_ZH_2018_mad_M50->Get("h_"+region+"ZH_"+variable)->Clone("h_TF_2018_mad_M50"); 
     h_TF_2018_M50_JEC                          	= (TH1F*)file_ZH_2018_M50_JEC->Get("h_"+region+"ZH_"+variable)->Clone("h_TF_2018_M50_JEC"); 
     h_TF_2018_mad_M50_JEC                          	= (TH1F*)file_ZH_2018_mad_M50_JEC->Get("h_"+region+"ZH_"+variable)->Clone("h_TF_2018_mad_M50_JEC"); 
     //h_TF_2018_M50_JEC_Zpt                          	= (TH1F*)file_ZH_2018_M50_JEC_Zpt->Get("h_"+region+"ZH_"+variable)->Clone("h_TF_2018_M50_JEC_Zpt"); 
     h_TF_2018_2J_JEC                          	= (TH1F*)file_ZH_2018_2J_JEC->Get("h_"+region+"ZH_"+variable)->Clone("h_TF_2018_2J_JEC"); 
    //cout<<h_TF_2018_M50_JEC_Zpt->GetBinContent(1)<<endl; 
    if(!variable.Contains("unit")) 
     {bool scale = true;
      if(scale){ 
	//fulllogname = fulllogname+"_scaled";

    h_TF_2016_M50->Scale(16.226/20.0);
    h_TF_2016_mad_M50->Scale(16.226/20.0);
    h_TF_2017_M50->Scale(.738*41.4/20.0);
    h_TF_2018_M50->Scale(.734*58.67/20.0);
    h_TF_2018_mad_M50->Scale(.734*58.67/20.0);
    h_TF_2018_M50_JEC->Scale(58.67/20.0);
    h_TF_2018_mad_M50_JEC->Scale(58.67/20.0);
    //h_TF_2018_M50_JEC_Zpt->Scale(58.67/20.0);
    h_TF_2018_2J_JEC->Scale(58.67/20.0);
	}
	}

    //cout<<h_TF_2018_M50_JEC_Zpt->GetBinContent(1)<<endl; 
     h_TF_2016_M50->Divide(h_DY_2016_M50); 
     h_TF_2016_mad_M50->Divide(h_DY_2016_mad_M50); 
     h_TF_2017_M50->Divide(h_DY_2017_M50); 
     h_TF_2018_M50->Divide(h_DY_2018_M50); 
     h_TF_2018_mad_M50->Divide(h_DY_2018_mad_M50); 
     h_TF_2018_M50_JEC->Divide(h_DY_2018_M50_JEC); 
     h_TF_2018_mad_M50_JEC->Divide(h_DY_2018_mad_M50_JEC); 
     //h_TF_2018_M50_JEC_Zpt->Divide(h_DY_2018_M50_JEC_Zpt); 
     h_TF_2018_2J_JEC->Divide(h_DY_2018_2J_JEC); 
    //cout<<h_TF_2018_M50_JEC_Zpt->GetBinContent(1)<<endl; 
     h_TF_hadd=(TH1F*)h_ZH_hadd->Clone("h_TF_hadd");
     h_TF_hadd->Divide(h_DY_hadd);

     h_TF_2016_madamc_M50=(TH1F*)h_ZH_2016_madamc_M50->Clone("h_TF_2016_madamc_M50");;
     h_TF_2016_madamc_M50->Divide(h_DY_2016_madamc_M50);

     h_TF_2018_madamc_M50=(TH1F*)h_ZH_2018_madamc_M50->Clone("h_TF_2018_madamc_M50");;
     h_TF_2018_madamc_M50->Divide(h_DY_2018_madamc_M50);
     	
     h_TF_hadd_madamc=(TH1F*)h_ZH_hadd_madamc->Clone("h_TF_hadd_madamc");;
     h_TF_hadd_madamc->Divide(h_DY_hadd_madamc);


 Float_t DY_Tag0_2016             	      =h_DY_2016_M50->GetBinContent(1);
 Float_t DY_mad_Tag0_2016             	      =h_DY_2016_mad_M50->GetBinContent(1);
 Float_t DY_madamc_Tag0_2016             	      =h_DY_2016_madamc_M50->GetBinContent(1);
 Float_t DY_Tag0_2017             	      =h_DY_2017_M50->GetBinContent(1);
 Float_t DY_Tag0_2018             	      =h_DY_2018_M50->GetBinContent(1);
 Float_t DY_mad_Tag0_2018             	      =h_DY_2018_mad_M50->GetBinContent(1);
 Float_t DY_madamc_Tag0_2018             	      =h_DY_2018_madamc_M50->GetBinContent(1);
 Float_t DY_Tag0_2018_JEC             	      =h_DY_2018_M50_JEC->GetBinContent(1);
 Float_t DY_mad_Tag0_2018_JEC             	      =h_DY_2018_mad_M50_JEC->GetBinContent(1);
 //Float_t DY_madamc_Tag0_2018_JEC             	      =h_DY_2018_madamc_M50_JEC->GetBinContent(1);
 //Float_t DY_Tag0_2018_JEC_Zpt             	      =h_DY_2018_M50_JEC_Zpt->GetBinContent(1);
 Float_t DY_Tag0_2018_2J_JEC             	      =h_DY_2018_2J_JEC->GetBinContent(1);
 Float_t DY_hadd_Tag0             	      =h_DY_hadd->GetBinContent(1);
 Float_t DY_hadd_madamc_Tag0             	      =h_DY_hadd_madamc->GetBinContent(1);


 Float_t ZH_Tag0_2016             	      =h_ZH_2016_M50->GetBinContent(1);
 Float_t ZH_mad_Tag0_2016             	      =h_ZH_2016_mad_M50->GetBinContent(1);
 Float_t ZH_madamc_Tag0_2016             	      =h_ZH_2016_madamc_M50->GetBinContent(1);
 Float_t ZH_Tag0_2017             	      =h_ZH_2017_M50->GetBinContent(1);
 Float_t ZH_Tag0_2018             	      =h_ZH_2018_M50->GetBinContent(1);
 Float_t ZH_mad_Tag0_2018             	      =h_ZH_2018_mad_M50->GetBinContent(1);
 Float_t ZH_madamc_Tag0_2018             	      =h_ZH_2018_madamc_M50->GetBinContent(1);
 Float_t ZH_Tag0_2018_JEC             	      =h_ZH_2018_M50_JEC->GetBinContent(1);
 Float_t ZH_mad_Tag0_2018_JEC             	      =h_ZH_2018_mad_M50_JEC->GetBinContent(1);
 //Float_t ZH_madamc_Tag0_2018_JEC             	      =h_ZH_2018_madamc_M50_JEC->GetBinContent(1);
 //Float_t ZH_Tag0_2018_JEC_Zpt             	      =h_ZH_2018_M50_JEC_Zpt->GetBinContent(1);
 Float_t ZH_Tag0_2018_2J_JEC             	      =h_ZH_2018_2J_JEC->GetBinContent(1);
 Float_t ZH_hadd_Tag0             	      =h_ZH_hadd->GetBinContent(1);
 Float_t ZH_hadd_madamc_Tag0             	      =h_ZH_hadd_madamc->GetBinContent(1);


 Float_t TF_Tag0_2016             	      =h_TF_2016_M50->GetBinContent(1);
 Float_t TF_mad_Tag0_2016             	      =h_TF_2016_mad_M50->GetBinContent(1);
 Float_t TF_madamc_Tag0_2016             	      =h_TF_2016_madamc_M50->GetBinContent(1);
 Float_t TF_Tag0_2017             	      =h_TF_2017_M50->GetBinContent(1);
 Float_t TF_Tag0_2018             	      =h_TF_2018_M50->GetBinContent(1);
 Float_t TF_mad_Tag0_2018             	      =h_TF_2018_mad_M50->GetBinContent(1);
 Float_t TF_madamc_Tag0_2018             	      =h_TF_2018_madamc_M50->GetBinContent(1);
 Float_t TF_Tag0_2018_JEC             	      =h_TF_2018_M50_JEC->GetBinContent(1);
 Float_t TF_mad_Tag0_2018_JEC             	      =h_TF_2018_mad_M50_JEC->GetBinContent(1);
 //Float_t TF_madamc_Tag0_2018_JEC             	      =h_TF_2018_madamc_M50_JEC->GetBinContent(1);
 //Float_t TF_Tag0_2018_JEC_Zpt             	      =h_TF_2018_M50_JEC_Zpt->GetBinContent(1);
 Float_t TF_Tag0_2018_2J_JEC             	      =h_TF_2018_2J_JEC->GetBinContent(1);
 Float_t TF_hadd_Tag0             	      =h_TF_hadd->GetBinContent(1);
 Float_t TF_hadd_madamc_Tag0             	      =h_TF_hadd_madamc->GetBinContent(1);



 Float_t Err_DY_Tag0_2016             	      =h_DY_2016_M50->GetBinError(1);
 Float_t Err_DY_mad_Tag0_2016             	      =h_DY_2016_mad_M50->GetBinError(1);
 Float_t Err_DY_madamc_Tag0_2016             	      =h_DY_2016_madamc_M50->GetBinError(1);
 Float_t Err_DY_Tag0_2017             	      =h_DY_2017_M50->GetBinError(1);
 Float_t Err_DY_Tag0_2018             	      =h_DY_2018_M50->GetBinError(1);
 Float_t Err_DY_mad_Tag0_2018             	      =h_DY_2018_mad_M50->GetBinError(1);
 Float_t Err_DY_madamc_Tag0_2018             	      =h_DY_2018_madamc_M50->GetBinError(1);
 Float_t Err_DY_Tag0_2018_JEC             	      =h_DY_2018_M50_JEC->GetBinError(1);
 Float_t Err_DY_mad_Tag0_2018_JEC             	      =h_DY_2018_mad_M50_JEC->GetBinError(1);
 //Float_t Err_DY_madamc_Tag0_2018_JEC             	      =h_DY_2018_madamc_M50_JEC->GetBinError(1);
 //Float_t Err_DY_Tag0_2018_JEC_Zpt             	      =h_DY_2018_M50_JEC_Zpt->GetBinError(1);
 Float_t Err_DY_Tag0_2018_2J_JEC             	      =h_DY_2018_2J_JEC->GetBinError(1);
 Float_t Err_DY_hadd_Tag0             	      =h_DY_hadd->GetBinError(1);
 Float_t Err_DY_hadd_madamc_Tag0             	      =h_DY_hadd_madamc->GetBinError(1);


 Float_t Err_ZH_Tag0_2016             	      =h_ZH_2016_M50->GetBinError(1);
 Float_t Err_ZH_mad_Tag0_2016             	      =h_ZH_2016_mad_M50->GetBinError(1);
 Float_t Err_ZH_madamc_Tag0_2016             	      =h_ZH_2016_madamc_M50->GetBinError(1);
 Float_t Err_ZH_Tag0_2017             	      =h_ZH_2017_M50->GetBinError(1);
 Float_t Err_ZH_Tag0_2018             	      =h_ZH_2018_M50->GetBinError(1);
 Float_t Err_ZH_mad_Tag0_2018             	      =h_ZH_2018_mad_M50->GetBinError(1);
 Float_t Err_ZH_madamc_Tag0_2018             	      =h_ZH_2018_madamc_M50->GetBinError(1);
 Float_t Err_ZH_Tag0_2018_JEC             	      =h_ZH_2018_M50_JEC->GetBinError(1);
 Float_t Err_ZH_mad_Tag0_2018_JEC             	      =h_ZH_2018_mad_M50_JEC->GetBinError(1);
 //Float_t Err_ZH_madamc_Tag0_2018_JEC             	      =h_ZH_2018_madamc_M50_JEC->GetBinError(1);
 //Float_t Err_ZH_Tag0_2018_JEC_Zpt             	      =h_ZH_2018_M50_JEC_Zpt->GetBinError(1);
 Float_t Err_ZH_Tag0_2018_2J_JEC             	      =h_ZH_2018_2J_JEC->GetBinError(1);
 Float_t Err_ZH_hadd_Tag0             	      =h_ZH_hadd->GetBinError(1);
 Float_t Err_ZH_hadd_madamc_Tag0             	      =h_ZH_hadd_madamc->GetBinError(1);


 Float_t Err_TF_Tag0_2016             	      =h_TF_2016_M50->GetBinError(1);
 Float_t Err_TF_mad_Tag0_2016             	      =h_TF_2016_mad_M50->GetBinError(1);
 Float_t Err_TF_madamc_Tag0_2016             	      =h_TF_2016_madamc_M50->GetBinError(1);
 Float_t Err_TF_Tag0_2017             	      =h_TF_2017_M50->GetBinError(1);
 Float_t Err_TF_Tag0_2018             	      =h_TF_2018_M50->GetBinError(1);
 Float_t Err_TF_mad_Tag0_2018             	      =h_TF_2018_mad_M50->GetBinError(1);
 Float_t Err_TF_madamc_Tag0_2018             	      =h_TF_2018_madamc_M50->GetBinError(1);
 Float_t Err_TF_Tag0_2018_JEC             	      =h_TF_2018_M50_JEC->GetBinError(1);
 Float_t Err_TF_mad_Tag0_2018_JEC             	      =h_TF_2018_mad_M50_JEC->GetBinError(1);
 //Float_t Err_TF_madamc_Tag0_2018_JEC             	      =h_TF_2018_madamc_M50_JEC->GetBinError(1);
 //Float_t Err_TF_Tag0_2018_JEC_Zpt             	      =h_TF_2018_M50_JEC_Zpt->GetBinError(1);
 Float_t Err_TF_Tag0_2018_2J_JEC             	      =h_TF_2018_2J_JEC->GetBinError(1);
 Float_t Err_TF_hadd_Tag0             	      =h_TF_hadd->GetBinError(1);
 Float_t Err_TF_hadd_madamc_Tag0             	      =h_TF_hadd_madamc->GetBinError(1);


 Float_t DY_Tag1_2016             	      =h_DY_2016_M50->GetBinContent(2);
 Float_t DY_mad_Tag1_2016             	      =h_DY_2016_mad_M50->GetBinContent(2);
 Float_t DY_madamc_Tag1_2016             	      =h_DY_2016_madamc_M50->GetBinContent(2);
 Float_t DY_Tag1_2017             	      =h_DY_2017_M50->GetBinContent(2);
 Float_t DY_Tag1_2018             	      =h_DY_2018_M50->GetBinContent(2);
 Float_t DY_mad_Tag1_2018             	      =h_DY_2018_mad_M50->GetBinContent(2);
 Float_t DY_madamc_Tag1_2018             	      =h_DY_2018_madamc_M50->GetBinContent(2);
 Float_t DY_Tag1_2018_JEC             	      =h_DY_2018_M50_JEC->GetBinContent(2);
 Float_t DY_mad_Tag1_2018_JEC             	      =h_DY_2018_mad_M50_JEC->GetBinContent(2);
 //Float_t DY_madamc_Tag1_2018_JEC             	      =h_DY_2018_madamc_M50_JEC->GetBinContent(2);
 //Float_t DY_Tag1_2018_JEC_Zpt             	      =h_DY_2018_M50_JEC_Zpt->GetBinContent(2);
 Float_t DY_Tag1_2018_2J_JEC             	      =h_DY_2018_2J_JEC->GetBinContent(2);
 Float_t DY_hadd_Tag1             	      =h_DY_hadd->GetBinContent(2);
 Float_t DY_hadd_madamc_Tag1             	      =h_DY_hadd_madamc->GetBinContent(2);


 Float_t ZH_Tag1_2016             	      =h_ZH_2016_M50->GetBinContent(2);
 Float_t ZH_mad_Tag1_2016             	      =h_ZH_2016_mad_M50->GetBinContent(2);
 Float_t ZH_madamc_Tag1_2016             	      =h_ZH_2016_madamc_M50->GetBinContent(2);
 Float_t ZH_Tag1_2017             	      =h_ZH_2017_M50->GetBinContent(2);
 Float_t ZH_Tag1_2018             	      =h_ZH_2018_M50->GetBinContent(2);
 Float_t ZH_mad_Tag1_2018             	      =h_ZH_2018_mad_M50->GetBinContent(2);
 Float_t ZH_madamc_Tag1_2018             	      =h_ZH_2018_madamc_M50->GetBinContent(2);
 Float_t ZH_Tag1_2018_JEC             	      =h_ZH_2018_M50_JEC->GetBinContent(2);
 Float_t ZH_mad_Tag1_2018_JEC             	      =h_ZH_2018_mad_M50_JEC->GetBinContent(2);
 //Float_t ZH_madamc_Tag1_2018_JEC             	      =h_ZH_2018_madamc_M50_JEC->GetBinContent(2);
 //Float_t ZH_Tag1_2018_JEC_Zpt             	      =h_ZH_2018_M50_JEC_Zpt->GetBinContent(2);
 Float_t ZH_Tag1_2018_2J_JEC             	      =h_ZH_2018_2J_JEC->GetBinContent(2);
 Float_t ZH_hadd_Tag1             	      =h_ZH_hadd->GetBinContent(2);
 Float_t ZH_hadd_madamc_Tag1             	      =h_ZH_hadd_madamc->GetBinContent(2);


 Float_t TF_Tag1_2016             	      =h_TF_2016_M50->GetBinContent(2);
 Float_t TF_mad_Tag1_2016             	      =h_TF_2016_mad_M50->GetBinContent(2);
 Float_t TF_madamc_Tag1_2016             	      =h_TF_2016_madamc_M50->GetBinContent(2);
 Float_t TF_Tag1_2017             	      =h_TF_2017_M50->GetBinContent(2);
 Float_t TF_Tag1_2018             	      =h_TF_2018_M50->GetBinContent(2);
 Float_t TF_mad_Tag1_2018             	      =h_TF_2018_mad_M50->GetBinContent(2);
 Float_t TF_madamc_Tag1_2018             	      =h_TF_2018_madamc_M50->GetBinContent(2);
 Float_t TF_Tag1_2018_JEC             	      =h_TF_2018_M50_JEC->GetBinContent(2);
 Float_t TF_mad_Tag1_2018_JEC             	      =h_TF_2018_mad_M50_JEC->GetBinContent(2);
 //Float_t TF_madamc_Tag1_2018_JEC             	      =h_TF_2018_madamc_M50_JEC->GetBinContent(2);
 //Float_t TF_Tag1_2018_JEC_Zpt             	      =h_TF_2018_M50_JEC_Zpt->GetBinContent(2);
 Float_t TF_Tag1_2018_2J_JEC             	      =h_TF_2018_2J_JEC->GetBinContent(2);
 Float_t TF_hadd_Tag1             	      =h_TF_hadd->GetBinContent(2);
 Float_t TF_hadd_madamc_Tag1             	      =h_TF_hadd_madamc->GetBinContent(2);



 Float_t Err_DY_Tag1_2016             	      =h_DY_2016_M50->GetBinError(2);
 Float_t Err_DY_mad_Tag1_2016             	      =h_DY_2016_mad_M50->GetBinError(2);
 Float_t Err_DY_madamc_Tag1_2016             	      =h_DY_2016_madamc_M50->GetBinError(2);
 Float_t Err_DY_Tag1_2017             	      =h_DY_2017_M50->GetBinError(2);
 Float_t Err_DY_Tag1_2018             	      =h_DY_2018_M50->GetBinError(2);
 Float_t Err_DY_mad_Tag1_2018             	      =h_DY_2018_mad_M50->GetBinError(2);
 Float_t Err_DY_madamc_Tag1_2018             	      =h_DY_2018_madamc_M50->GetBinError(2);
 Float_t Err_DY_Tag1_2018_JEC             	      =h_DY_2018_M50_JEC->GetBinError(2);
 Float_t Err_DY_mad_Tag1_2018_JEC             	      =h_DY_2018_mad_M50_JEC->GetBinError(2);
 //Float_t Err_DY_madamc_Tag1_2018_JEC             	      =h_DY_2018_madamc_M50_JEC->GetBinError(2);
 //Float_t Err_DY_Tag1_2018_JEC_Zpt             	      =h_DY_2018_M50_JEC_Zpt->GetBinError(2);
 Float_t Err_DY_Tag1_2018_2J_JEC             	      =h_DY_2018_2J_JEC->GetBinError(2);
 Float_t Err_DY_hadd_Tag1             	      =h_DY_hadd->GetBinError(2);
 Float_t Err_DY_hadd_madamc_Tag1             	      =h_DY_hadd_madamc->GetBinError(2);


 Float_t Err_ZH_Tag1_2016             	      =h_ZH_2016_M50->GetBinError(2);
 Float_t Err_ZH_mad_Tag1_2016             	      =h_ZH_2016_mad_M50->GetBinError(2);
 Float_t Err_ZH_madamc_Tag1_2016             	      =h_ZH_2016_madamc_M50->GetBinError(2);
 Float_t Err_ZH_Tag1_2017             	      =h_ZH_2017_M50->GetBinError(2);
 Float_t Err_ZH_Tag1_2018             	      =h_ZH_2018_M50->GetBinError(2);
 Float_t Err_ZH_mad_Tag1_2018             	      =h_ZH_2018_mad_M50->GetBinError(2);
 Float_t Err_ZH_madamc_Tag1_2018             	      =h_ZH_2018_madamc_M50->GetBinError(2);
 Float_t Err_ZH_Tag1_2018_JEC             	      =h_ZH_2018_M50_JEC->GetBinError(2);
 Float_t Err_ZH_mad_Tag1_2018_JEC             	      =h_ZH_2018_mad_M50_JEC->GetBinError(2);
 //Float_t Err_ZH_madamc_Tag1_2018_JEC             	      =h_ZH_2018_madamc_M50_JEC->GetBinError(2);
 //Float_t Err_ZH_Tag1_2018_JEC_Zpt             	      =h_ZH_2018_M50_JEC_Zpt->GetBinError(2);
 Float_t Err_ZH_Tag1_2018_2J_JEC             	      =h_ZH_2018_2J_JEC->GetBinError(2);
 Float_t Err_ZH_hadd_Tag1             	      =h_ZH_hadd->GetBinError(2);
 Float_t Err_ZH_hadd_madamc_Tag1             	      =h_ZH_hadd_madamc->GetBinError(2);


 Float_t Err_TF_Tag1_2016             	      =h_TF_2016_M50->GetBinError(2);
 Float_t Err_TF_mad_Tag1_2016             	      =h_TF_2016_mad_M50->GetBinError(2);
 Float_t Err_TF_madamc_Tag1_2016             	      =h_TF_2016_madamc_M50->GetBinError(2);
 Float_t Err_TF_Tag1_2017             	      =h_TF_2017_M50->GetBinError(2);
 Float_t Err_TF_Tag1_2018             	      =h_TF_2018_M50->GetBinError(2);
 Float_t Err_TF_mad_Tag1_2018             	      =h_TF_2018_mad_M50->GetBinError(2);
 Float_t Err_TF_madamc_Tag1_2018             	      =h_TF_2018_madamc_M50->GetBinError(2);
 Float_t Err_TF_Tag1_2018_JEC             	      =h_TF_2018_M50_JEC->GetBinError(2);
 Float_t Err_TF_mad_Tag1_2018_JEC             	      =h_TF_2018_mad_M50_JEC->GetBinError(2);
 //Float_t Err_TF_madamc_Tag1_2018_JEC             	      =h_TF_2018_madamc_M50_JEC->GetBinError(2);
 //Float_t Err_TF_Tag1_2018_JEC_Zpt             	      =h_TF_2018_M50_JEC_Zpt->GetBinError(2);
 Float_t Err_TF_Tag1_2018_2J_JEC             	      =h_TF_2018_2J_JEC->GetBinError(2);
 Float_t Err_TF_hadd_Tag1             	      =h_TF_hadd->GetBinError(2);
 Float_t Err_TF_hadd_madamc_Tag1             	      =h_TF_hadd_madamc->GetBinError(2);


 Float_t DY_Tag2_2016             	      =h_DY_2016_M50->GetBinContent(3);
 Float_t DY_mad_Tag2_2016             	      =h_DY_2016_mad_M50->GetBinContent(3);
 Float_t DY_madamc_Tag2_2016             	      =h_DY_2016_madamc_M50->GetBinContent(3);
 Float_t DY_Tag2_2017             	      =h_DY_2017_M50->GetBinContent(3);
 Float_t DY_Tag2_2018             	      =h_DY_2018_M50->GetBinContent(3);
 Float_t DY_mad_Tag2_2018             	      =h_DY_2018_mad_M50->GetBinContent(3);
 Float_t DY_madamc_Tag2_2018             	      =h_DY_2018_madamc_M50->GetBinContent(3);
 Float_t DY_Tag2_2018_JEC             	      =h_DY_2018_M50_JEC->GetBinContent(3);
 Float_t DY_mad_Tag2_2018_JEC             	      =h_DY_2018_mad_M50_JEC->GetBinContent(3);
 //Float_t DY_madamc_Tag2_2018_JEC             	      =h_DY_2018_madamc_M50_JEC->GetBinContent(3);
 //Float_t DY_Tag2_2018_JEC_Zpt             	      =h_DY_2018_M50_JEC_Zpt->GetBinContent(3);
 Float_t DY_Tag2_2018_2J_JEC             	      =h_DY_2018_2J_JEC->GetBinContent(3);
 Float_t DY_hadd_Tag2             	      =h_DY_hadd->GetBinContent(3);
 Float_t DY_hadd_madamc_Tag2             	      =h_DY_hadd_madamc->GetBinContent(3);


 Float_t ZH_Tag2_2016             	      =h_ZH_2016_M50->GetBinContent(3);
 Float_t ZH_mad_Tag2_2016             	      =h_ZH_2016_mad_M50->GetBinContent(3);
 Float_t ZH_madamc_Tag2_2016             	      =h_ZH_2016_madamc_M50->GetBinContent(3);
 Float_t ZH_Tag2_2017             	      =h_ZH_2017_M50->GetBinContent(3);
 Float_t ZH_Tag2_2018             	      =h_ZH_2018_M50->GetBinContent(3);
 Float_t ZH_mad_Tag2_2018             	      =h_ZH_2018_mad_M50->GetBinContent(3);
 Float_t ZH_madamc_Tag2_2018             	      =h_ZH_2018_madamc_M50->GetBinContent(3);
 Float_t ZH_Tag2_2018_JEC             	      =h_ZH_2018_M50_JEC->GetBinContent(3);
 Float_t ZH_mad_Tag2_2018_JEC             	      =h_ZH_2018_mad_M50_JEC->GetBinContent(3);
 //Float_t ZH_madamc_Tag2_2018_JEC             	      =h_ZH_2018_madamc_M50_JEC->GetBinContent(3);
 //Float_t ZH_Tag2_2018_JEC_Zpt             	      =h_ZH_2018_M50_JEC_Zpt->GetBinContent(3);
 Float_t ZH_Tag2_2018_2J_JEC             	      =h_ZH_2018_2J_JEC->GetBinContent(3);
 Float_t ZH_hadd_Tag2             	      =h_ZH_hadd->GetBinContent(3);
 Float_t ZH_hadd_madamc_Tag2             	      =h_ZH_hadd_madamc->GetBinContent(3);


 Float_t TF_Tag2_2016             	      =h_TF_2016_M50->GetBinContent(3);
 Float_t TF_mad_Tag2_2016             	      =h_TF_2016_mad_M50->GetBinContent(3);
 Float_t TF_madamc_Tag2_2016             	      =h_TF_2016_madamc_M50->GetBinContent(3);
 Float_t TF_Tag2_2017             	      =h_TF_2017_M50->GetBinContent(3);
 Float_t TF_Tag2_2018             	      =h_TF_2018_M50->GetBinContent(3);
 Float_t TF_mad_Tag2_2018             	      =h_TF_2018_mad_M50->GetBinContent(3);
 Float_t TF_madamc_Tag2_2018             	      =h_TF_2018_madamc_M50->GetBinContent(3);
 Float_t TF_Tag2_2018_JEC             	      =h_TF_2018_M50_JEC->GetBinContent(3);
 Float_t TF_mad_Tag2_2018_JEC             	      =h_TF_2018_mad_M50_JEC->GetBinContent(3);
 //Float_t TF_madamc_Tag2_2018_JEC             	      =h_TF_2018_madamc_M50_JEC->GetBinContent(3);
 //Float_t TF_Tag2_2018_JEC_Zpt             	      =h_TF_2018_M50_JEC_Zpt->GetBinContent(3);
 Float_t TF_Tag2_2018_2J_JEC             	      =h_TF_2018_2J_JEC->GetBinContent(3);
 Float_t TF_hadd_Tag2             	      =h_TF_hadd->GetBinContent(3);
 Float_t TF_hadd_madamc_Tag2             	      =h_TF_hadd_madamc->GetBinContent(3);



 Float_t Err_DY_Tag2_2016             	      =h_DY_2016_M50->GetBinError(3);
 Float_t Err_DY_mad_Tag2_2016             	      =h_DY_2016_mad_M50->GetBinError(3);
 Float_t Err_DY_madamc_Tag2_2016             	      =h_DY_2016_madamc_M50->GetBinError(3);
 Float_t Err_DY_Tag2_2017             	      =h_DY_2017_M50->GetBinError(3);
 Float_t Err_DY_Tag2_2018             	      =h_DY_2018_M50->GetBinError(3);
 Float_t Err_DY_mad_Tag2_2018             	      =h_DY_2018_mad_M50->GetBinError(3);
 Float_t Err_DY_madamc_Tag2_2018             	      =h_DY_2018_madamc_M50->GetBinError(3);
 Float_t Err_DY_Tag2_2018_JEC             	      =h_DY_2018_M50_JEC->GetBinError(3);
 Float_t Err_DY_mad_Tag2_2018_JEC             	      =h_DY_2018_mad_M50_JEC->GetBinError(3);
 //Float_t Err_DY_madamc_Tag2_2018_JEC             	      =h_DY_2018_madamc_M50_JEC->GetBinError(3);
 //Float_t Err_DY_Tag2_2018_JEC_Zpt             	      =h_DY_2018_M50_JEC_Zpt->GetBinError(3);
 Float_t Err_DY_Tag2_2018_2J_JEC             	      =h_DY_2018_2J_JEC->GetBinError(3);
 Float_t Err_DY_hadd_Tag2             	      =h_DY_hadd->GetBinError(3);
 Float_t Err_DY_hadd_madamc_Tag2             	      =h_DY_hadd_madamc->GetBinError(3);


 Float_t Err_ZH_Tag2_2016             	      =h_ZH_2016_M50->GetBinError(3);
 Float_t Err_ZH_mad_Tag2_2016             	      =h_ZH_2016_mad_M50->GetBinError(3);
 Float_t Err_ZH_madamc_Tag2_2016             	      =h_ZH_2016_madamc_M50->GetBinError(3);
 Float_t Err_ZH_Tag2_2017             	      =h_ZH_2017_M50->GetBinError(3);
 Float_t Err_ZH_Tag2_2018             	      =h_ZH_2018_M50->GetBinError(3);
 Float_t Err_ZH_mad_Tag2_2018             	      =h_ZH_2018_mad_M50->GetBinError(3);
 Float_t Err_ZH_madamc_Tag2_2018             	      =h_ZH_2018_madamc_M50->GetBinError(3);
 Float_t Err_ZH_Tag2_2018_JEC             	      =h_ZH_2018_M50_JEC->GetBinError(3);
 Float_t Err_ZH_mad_Tag2_2018_JEC             	      =h_ZH_2018_mad_M50_JEC->GetBinError(3);
 //Float_t Err_ZH_madamc_Tag2_2018_JEC             	      =h_ZH_2018_madamc_M50_JEC->GetBinError(3);
 //Float_t Err_ZH_Tag2_2018_JEC_Zpt             	      =h_ZH_2018_M50_JEC_Zpt->GetBinError(3);
 Float_t Err_ZH_Tag2_2018_2J_JEC             	      =h_ZH_2018_2J_JEC->GetBinError(3);
 Float_t Err_ZH_hadd_Tag2             	      =h_ZH_hadd->GetBinError(3);
 Float_t Err_ZH_hadd_madamc_Tag2             	      =h_ZH_hadd_madamc->GetBinError(3);


 Float_t Err_TF_Tag2_2016             	      =h_TF_2016_M50->GetBinError(3);
 Float_t Err_TF_mad_Tag2_2016             	      =h_TF_2016_mad_M50->GetBinError(3);
 Float_t Err_TF_madamc_Tag2_2016             	      =h_TF_2016_madamc_M50->GetBinError(3);
 Float_t Err_TF_Tag2_2017             	      =h_TF_2017_M50->GetBinError(3);
 Float_t Err_TF_Tag2_2018             	      =h_TF_2018_M50->GetBinError(3);
 Float_t Err_TF_mad_Tag2_2018             	      =h_TF_2018_mad_M50->GetBinError(3);
 Float_t Err_TF_madamc_Tag2_2018             	      =h_TF_2018_madamc_M50->GetBinError(3);
 Float_t Err_TF_Tag2_2018_JEC             	      =h_TF_2018_M50_JEC->GetBinError(3);
 Float_t Err_TF_mad_Tag2_2018_JEC             	      =h_TF_2018_mad_M50_JEC->GetBinError(3);
 //Float_t Err_TF_madamc_Tag2_2018_JEC             	      =h_TF_2018_madamc_M50_JEC->GetBinError(3);
 //Float_t Err_TF_Tag2_2018_JEC_Zpt             	      =h_TF_2018_M50_JEC_Zpt->GetBinError(3);
 Float_t Err_TF_Tag2_2018_2J_JEC             	      =h_TF_2018_2J_JEC->GetBinError(3);
 Float_t Err_TF_hadd_Tag2             	      =h_TF_hadd->GetBinError(3);
 Float_t Err_TF_hadd_madamc_Tag2             	      =h_TF_hadd_madamc->GetBinError(3);








     if(domaketable){
      FILE * outfulltable;
      outfulltable = fopen (fulllogname+".tex","w");
       fprintf (outfulltable, "\\documentclass{article}\n\n");
       fprintf (outfulltable, "\\begin{document}\n\n");
       fprintf (outfulltable, "\\begin{tabular}{rll}\n\n");
       //fprintf (outfulltable, " \\Huge %s & \\Huge %s   \\\\\n", lepton.Data(), region.Data()); 
       fprintf (outfulltable, " \\Huge %s   \\\\\n", region.Data()); 
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\hline \n");

  
      
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\LowZ \n");
       fprintf (outfulltable, "2016 DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", DY_Tag0_2016         ,Err_DY_Tag0_2016   	) ; 
       fprintf (outfulltable, "2016 mad DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", DY_mad_Tag0_2016         ,Err_DY_mad_Tag0_2016   	) ; 
       fprintf (outfulltable, "2016 madamc DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", DY_madamc_Tag0_2016         ,Err_DY_madamc_Tag0_2016   	) ; 
       fprintf (outfulltable, "2017 DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", DY_Tag0_2017         ,Err_DY_Tag0_2017   	) ; 
       fprintf (outfulltable, "2018 DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", DY_Tag0_2018         ,Err_DY_Tag0_2018   	) ; 
       fprintf (outfulltable, "2018 mad DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", DY_mad_Tag0_2018         ,Err_DY_mad_Tag0_2018   	) ; 
       fprintf (outfulltable, "2018 madamc DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", DY_madamc_Tag0_2018         ,Err_DY_madamc_Tag0_2018   	) ; 
       fprintf (outfulltable, "2018 DY50 JEC & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", DY_Tag0_2018_JEC         ,Err_DY_Tag0_2018_JEC) ; 
       fprintf (outfulltable, "2018 mad DY50 JEC & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", DY_mad_Tag0_2018_JEC         ,Err_DY_mad_Tag0_2018_JEC) ; 
       //fprintf (outfulltable, "2018 madamc DY50 JEC & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", DY_madamc_Tag0_2018_JEC         ,Err_DY_madamc_Tag0_2018_JEC) ; 
       //fprintf (outfulltable, "2018 DY50 JEC Zpt & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", DY_Tag0_2018_JEC_Zpt         ,Err_DY_Tag0_2018_JEC_Zpt) ; 
       fprintf (outfulltable, "2018 DY2J JEC & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", DY_Tag0_2018_2J_JEC         ,Err_DY_Tag0_2018_2J_JEC) ; 
       fprintf (outfulltable, "hadded Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", DY_hadd_Tag0         ,Err_DY_hadd_Tag0   	) ; 
       fprintf (outfulltable, "hadd madamc Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", DY_hadd_madamc_Tag0         ,Err_DY_hadd_madamc_Tag0   	) ; 
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\HighZ \n");
       fprintf (outfulltable, "2016 DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", ZH_Tag0_2016         ,Err_ZH_Tag0_2016   	) ; 
       fprintf (outfulltable, "2016 mad DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", ZH_mad_Tag0_2016         ,Err_ZH_mad_Tag0_2016   	) ; 
       fprintf (outfulltable, "2016 madamc DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", ZH_madamc_Tag0_2016         ,Err_ZH_madamc_Tag0_2016   	) ; 
       fprintf (outfulltable, "2017 DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", ZH_Tag0_2017         ,Err_ZH_Tag0_2017   	) ; 
       fprintf (outfulltable, "2018 DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", ZH_Tag0_2018         ,Err_ZH_Tag0_2018   	) ; 
       fprintf (outfulltable, "2018 mad DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", ZH_mad_Tag0_2018         ,Err_ZH_mad_Tag0_2018   	) ; 
       fprintf (outfulltable, "2018 madamc DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", ZH_madamc_Tag0_2018         ,Err_ZH_madamc_Tag0_2018   	) ; 
       fprintf (outfulltable, "2018 DY50 JEC & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", ZH_Tag0_2018_JEC         ,Err_ZH_Tag0_2018_JEC) ; 
       fprintf (outfulltable, "2018 mad DY50 JEC & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", ZH_mad_Tag0_2018_JEC         ,Err_ZH_mad_Tag0_2018_JEC) ; 
       //fprintf (outfulltable, "2018 madamc DY50 JEC & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", ZH_madamc_Tag0_2018_JEC         ,Err_ZH_madamc_Tag0_2018_JEC) ; 
       //fprintf (outfulltable, "2018 DY50 JEC Zpt & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", ZH_Tag0_2018_JEC_Zpt         ,Err_ZH_Tag0_2018_JEC_Zpt) ; 
       fprintf (outfulltable, "2018 DY2J JEC & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", ZH_Tag0_2018_2J_JEC         ,Err_ZH_Tag0_2018_2J_JEC) ; 
       fprintf (outfulltable, "hadded Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", ZH_hadd_Tag0         ,Err_ZH_hadd_Tag0   	) ; 
       fprintf (outfulltable, "hadd madamc Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", ZH_hadd_madamc_Tag0         ,Err_ZH_hadd_madamc_Tag0   	) ; 
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\TF \n");
       fprintf (outfulltable, "2016 DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", TF_Tag0_2016         ,Err_TF_Tag0_2016   	) ; 
       fprintf (outfulltable, "2016 mad DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", TF_mad_Tag0_2016         ,Err_TF_mad_Tag0_2016   	) ; 
       fprintf (outfulltable, "2016 madamc DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", TF_madamc_Tag0_2016         ,Err_TF_madamc_Tag0_2016   	) ; 
       fprintf (outfulltable, "2017 DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", TF_Tag0_2017         ,Err_TF_Tag0_2017   	) ; 
       fprintf (outfulltable, "2018 DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", TF_Tag0_2018         ,Err_TF_Tag0_2018   	) ; 
       fprintf (outfulltable, "2018 mad DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", TF_mad_Tag0_2018         ,Err_TF_mad_Tag0_2018   	) ; 
       fprintf (outfulltable, "2018 madamc DY50 & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", TF_madamc_Tag0_2018         ,Err_TF_madamc_Tag0_2018   	) ; 
       fprintf (outfulltable, "2018 DY50 JEC & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", TF_Tag0_2018_JEC         ,Err_TF_Tag0_2018_JEC) ; 
       fprintf (outfulltable, "2018 mad DY50 JEC & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", TF_mad_Tag0_2018_JEC         ,Err_TF_mad_Tag0_2018_JEC) ; 
       //fprintf (outfulltable, "2018 madamc DY50 JEC & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", TF_madamc_Tag0_2018_JEC         ,Err_TF_madamc_Tag0_2018_JEC) ; 
       //fprintf (outfulltable, "2018 DY50 JEC Zpt & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", TF_Tag0_2018_JEC_Zpt         ,Err_TF_Tag0_2018_JEC_Zpt) ; 
       fprintf (outfulltable, "2018 DY2J JEC & Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", TF_Tag0_2018_2J_JEC         ,Err_TF_Tag0_2018_2J_JEC) ; 
       fprintf (outfulltable, "hadded Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", TF_hadd_Tag0         ,Err_TF_hadd_Tag0   	) ; 
       fprintf (outfulltable, "hadd madamc Tag0 bin Content:%8.6f & Tag0 bin Error:%8.6f\\\\\n", TF_hadd_madamc_Tag0         ,Err_TF_hadd_madamc_Tag0   	) ; 
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\LowZ \n");
       fprintf (outfulltable, "2016 DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", DY_Tag1_2016         ,Err_DY_Tag1_2016   	) ; 
       fprintf (outfulltable, "2016 mad DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", DY_mad_Tag1_2016         ,Err_DY_mad_Tag1_2016   	) ; 
       fprintf (outfulltable, "2016 madamc DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", DY_madamc_Tag1_2016         ,Err_DY_madamc_Tag1_2016   	) ; 
       fprintf (outfulltable, "2017 DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", DY_Tag1_2017         ,Err_DY_Tag1_2017   	) ; 
       fprintf (outfulltable, "2018 DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", DY_Tag1_2018         ,Err_DY_Tag1_2018   	) ; 
       fprintf (outfulltable, "2018 mad DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", DY_mad_Tag1_2018         ,Err_DY_mad_Tag1_2018   	) ; 
       fprintf (outfulltable, "2018 madamc DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", DY_madamc_Tag1_2018         ,Err_DY_madamc_Tag1_2018   	) ; 
       fprintf (outfulltable, "2018 DY50 JEC & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", DY_Tag1_2018_JEC         ,Err_DY_Tag1_2018_JEC) ; 
       fprintf (outfulltable, "2018 mad DY50 JEC & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", DY_mad_Tag1_2018_JEC         ,Err_DY_mad_Tag1_2018_JEC) ; 
       //fprintf (outfulltable, "2018 madamc DY50 JEC & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", DY_madamc_Tag1_2018_JEC         ,Err_DY_madamc_Tag1_2018_JEC) ; 
       //fprintf (outfulltable, "2018 DY50 JEC Zpt & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", DY_Tag1_2018_JEC_Zpt         ,Err_DY_Tag1_2018_JEC_Zpt) ; 
       fprintf (outfulltable, "2018 DY2J JEC & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", DY_Tag1_2018_2J_JEC         ,Err_DY_Tag1_2018_2J_JEC) ; 
       fprintf (outfulltable, "hadded Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", DY_hadd_Tag1         ,Err_DY_hadd_Tag1   	) ; 
       fprintf (outfulltable, "hadd madamc Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", DY_hadd_madamc_Tag1         ,Err_DY_hadd_madamc_Tag1   	) ; 
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\HighZ \n");
       fprintf (outfulltable, "2016 DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", ZH_Tag1_2016         ,Err_ZH_Tag1_2016   	) ; 
       fprintf (outfulltable, "2016 mad DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", ZH_mad_Tag1_2016         ,Err_ZH_mad_Tag1_2016   	) ; 
       fprintf (outfulltable, "2016 madamc DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", ZH_madamc_Tag1_2016         ,Err_ZH_madamc_Tag1_2016   	) ; 
       fprintf (outfulltable, "2017 DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", ZH_Tag1_2017         ,Err_ZH_Tag1_2017   	) ; 
       fprintf (outfulltable, "2018 DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", ZH_Tag1_2018         ,Err_ZH_Tag1_2018   	) ; 
       fprintf (outfulltable, "2018 mad DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", ZH_mad_Tag1_2018         ,Err_ZH_mad_Tag1_2018   	) ; 
       fprintf (outfulltable, "2018 madamc DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", ZH_madamc_Tag1_2018         ,Err_ZH_madamc_Tag1_2018   	) ; 
       fprintf (outfulltable, "2018 DY50 JEC & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", ZH_Tag1_2018_JEC         ,Err_ZH_Tag1_2018_JEC) ; 
       fprintf (outfulltable, "2018 mad DY50 JEC & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", ZH_mad_Tag1_2018_JEC         ,Err_ZH_mad_Tag1_2018_JEC) ; 
       //fprintf (outfulltable, "2018 madamc DY50 JEC & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", ZH_madamc_Tag1_2018_JEC         ,Err_ZH_madamc_Tag1_2018_JEC) ; 
       //fprintf (outfulltable, "2018 DY50 JEC Zpt & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", ZH_Tag1_2018_JEC_Zpt         ,Err_ZH_Tag1_2018_JEC_Zpt) ; 
       fprintf (outfulltable, "2018 DY2J JEC & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", ZH_Tag1_2018_2J_JEC         ,Err_ZH_Tag1_2018_2J_JEC) ; 
       fprintf (outfulltable, "hadded Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", ZH_hadd_Tag1         ,Err_ZH_hadd_Tag1   	) ; 
       fprintf (outfulltable, "hadd madamc Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", ZH_hadd_madamc_Tag1         ,Err_ZH_hadd_madamc_Tag1   	) ; 
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\TF \n");
       fprintf (outfulltable, "2016 DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", TF_Tag1_2016         ,Err_TF_Tag1_2016   	) ; 
       fprintf (outfulltable, "2016 mad DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", TF_mad_Tag1_2016         ,Err_TF_mad_Tag1_2016   	) ; 
       fprintf (outfulltable, "2016 madamc DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", TF_madamc_Tag1_2016         ,Err_TF_madamc_Tag1_2016   	) ; 
       fprintf (outfulltable, "2017 DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", TF_Tag1_2017         ,Err_TF_Tag1_2017   	) ; 
       fprintf (outfulltable, "2018 DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", TF_Tag1_2018         ,Err_TF_Tag1_2018   	) ; 
       fprintf (outfulltable, "2018 mad DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", TF_mad_Tag1_2018         ,Err_TF_mad_Tag1_2018   	) ; 
       fprintf (outfulltable, "2018 madamc DY50 & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", TF_madamc_Tag1_2018         ,Err_TF_madamc_Tag1_2018   	) ; 
       fprintf (outfulltable, "2018 DY50 JEC & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", TF_Tag1_2018_JEC         ,Err_TF_Tag1_2018_JEC) ; 
       fprintf (outfulltable, "2018 mad DY50 JEC & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", TF_mad_Tag1_2018_JEC         ,Err_TF_mad_Tag1_2018_JEC) ; 
       //fprintf (outfulltable, "2018 madamc DY50 JEC & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", TF_madamc_Tag1_2018_JEC         ,Err_TF_madamc_Tag1_2018_JEC) ; 
       //fprintf (outfulltable, "2018 DY50 JEC Zpt & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", TF_Tag1_2018_JEC_Zpt         ,Err_TF_Tag1_2018_JEC_Zpt) ; 
       fprintf (outfulltable, "2018 DY2J JEC & Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", TF_Tag1_2018_2J_JEC         ,Err_TF_Tag1_2018_2J_JEC) ; 
       fprintf (outfulltable, "hadded Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", TF_hadd_Tag1         ,Err_TF_hadd_Tag1   	) ; 
       fprintf (outfulltable, "hadd madamc Tag1 bin Content:%8.6f & Tag1 bin Error:%8.6f\\\\\n", TF_hadd_madamc_Tag1         ,Err_TF_hadd_madamc_Tag1   	) ; 
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\LowZ \n");
       fprintf (outfulltable, "2016 DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", DY_Tag2_2016         ,Err_DY_Tag2_2016   	) ; 
       fprintf (outfulltable, "2016 mad DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", DY_mad_Tag2_2016         ,Err_DY_mad_Tag2_2016   	) ; 
       fprintf (outfulltable, "2016 madamc DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", DY_madamc_Tag2_2016         ,Err_DY_madamc_Tag2_2016   	) ; 
       fprintf (outfulltable, "2017 DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", DY_Tag2_2017         ,Err_DY_Tag2_2017   	) ; 
       fprintf (outfulltable, "2018 DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", DY_Tag2_2018         ,Err_DY_Tag2_2018   	) ; 
       fprintf (outfulltable, "2018 mad DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", DY_mad_Tag2_2018         ,Err_DY_mad_Tag2_2018   	) ; 
       fprintf (outfulltable, "2018 madamc DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", DY_madamc_Tag2_2018         ,Err_DY_madamc_Tag2_2018   	) ; 
       fprintf (outfulltable, "2018 DY50 JEC & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", DY_Tag2_2018_JEC         ,Err_DY_Tag2_2018_JEC) ; 
       fprintf (outfulltable, "2018 mad DY50 JEC & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", DY_mad_Tag2_2018_JEC         ,Err_DY_mad_Tag2_2018_JEC) ; 
       //fprintf (outfulltable, "2018 madamc DY50 JEC & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", DY_madamc_Tag2_2018_JEC         ,Err_DY_madamc_Tag2_2018_JEC) ; 
       //fprintf (outfulltable, "2018 DY50 JEC Zpt & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", DY_Tag2_2018_JEC_Zpt         ,Err_DY_Tag2_2018_JEC_Zpt) ; 
       fprintf (outfulltable, "2018 DY2J JEC & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", DY_Tag2_2018_2J_JEC         ,Err_DY_Tag2_2018_2J_JEC) ; 
       fprintf (outfulltable, "hadded Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", DY_hadd_Tag2         ,Err_DY_hadd_Tag2   	) ; 
       fprintf (outfulltable, "hadd madamc Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", DY_hadd_madamc_Tag2         ,Err_DY_hadd_madamc_Tag2   	) ; 
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\HighZ \n");
       fprintf (outfulltable, "2016 DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", ZH_Tag2_2016         ,Err_ZH_Tag2_2016   	) ; 
       fprintf (outfulltable, "2016 mad DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", ZH_mad_Tag2_2016         ,Err_ZH_mad_Tag2_2016   	) ; 
       fprintf (outfulltable, "2016 madamc DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", ZH_madamc_Tag2_2016         ,Err_ZH_madamc_Tag2_2016   	) ; 
       fprintf (outfulltable, "2017 DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", ZH_Tag2_2017         ,Err_ZH_Tag2_2017   	) ; 
       fprintf (outfulltable, "2018 DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", ZH_Tag2_2018         ,Err_ZH_Tag2_2018   	) ; 
       fprintf (outfulltable, "2018 mad DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", ZH_mad_Tag2_2018         ,Err_ZH_mad_Tag2_2018   	) ; 
       fprintf (outfulltable, "2018 madamc DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", ZH_madamc_Tag2_2018         ,Err_ZH_madamc_Tag2_2018   	) ; 
       fprintf (outfulltable, "2018 DY50 JEC & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", ZH_Tag2_2018_JEC         ,Err_ZH_Tag2_2018_JEC) ; 
       fprintf (outfulltable, "2018 mad DY50 JEC & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", ZH_mad_Tag2_2018_JEC         ,Err_ZH_mad_Tag2_2018_JEC) ; 
       //fprintf (outfulltable, "2018 madamc DY50 JEC & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", ZH_madamc_Tag2_2018_JEC         ,Err_ZH_madamc_Tag2_2018_JEC) ; 
       //fprintf (outfulltable, "2018 DY50 JEC Zpt & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", ZH_Tag2_2018_JEC_Zpt         ,Err_ZH_Tag2_2018_JEC_Zpt) ; 
       fprintf (outfulltable, "2018 DY2J JEC & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", ZH_Tag2_2018_2J_JEC         ,Err_ZH_Tag2_2018_2J_JEC) ; 
       fprintf (outfulltable, "hadded Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", ZH_hadd_Tag2         ,Err_ZH_hadd_Tag2   	) ; 
       fprintf (outfulltable, "hadd madamc Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", ZH_hadd_madamc_Tag2         ,Err_ZH_hadd_madamc_Tag2   	) ; 
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\TF \n");
       fprintf (outfulltable, "2016 DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", TF_Tag2_2016         ,Err_TF_Tag2_2016   	) ; 
       fprintf (outfulltable, "2016 mad DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", TF_mad_Tag2_2016         ,Err_TF_mad_Tag2_2016   	) ; 
       fprintf (outfulltable, "2016 madamc DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", TF_madamc_Tag2_2016         ,Err_TF_madamc_Tag2_2016   	) ; 
       fprintf (outfulltable, "2017 DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", TF_Tag2_2017         ,Err_TF_Tag2_2017   	) ; 
       fprintf (outfulltable, "2018 DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", TF_Tag2_2018         ,Err_TF_Tag2_2018   	) ; 
       fprintf (outfulltable, "2018 mad DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", TF_mad_Tag2_2018         ,Err_TF_mad_Tag2_2018   	) ; 
       fprintf (outfulltable, "2018 madamc DY50 & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", TF_madamc_Tag2_2018         ,Err_TF_madamc_Tag2_2018   	) ; 
       fprintf (outfulltable, "2018 DY50 JEC & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", TF_Tag2_2018_JEC         ,Err_TF_Tag2_2018_JEC) ; 
       fprintf (outfulltable, "2018 mad DY50 JEC & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", TF_mad_Tag2_2018_JEC         ,Err_TF_mad_Tag2_2018_JEC) ; 
       //fprintf (outfulltable, "2018 madamc DY50 JEC & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", TF_madamc_Tag2_2018_JEC         ,Err_TF_madamc_Tag2_2018_JEC) ; 
       //fprintf (outfulltable, "2018 DY50 JEC Zpt & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", TF_Tag2_2018_JEC_Zpt         ,Err_TF_Tag2_2018_JEC_Zpt) ; 
       fprintf (outfulltable, "2018 DY2J JEC & Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", TF_Tag2_2018_2J_JEC         ,Err_TF_Tag2_2018_2J_JEC) ; 
       fprintf (outfulltable, "hadded Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", TF_hadd_Tag2         ,Err_TF_hadd_Tag2   	) ; 
       fprintf (outfulltable, "hadd madamc Tag2 bin Content:%8.6f & Tag2 bin Error:%8.6f\\\\\n", TF_hadd_madamc_Tag2         ,Err_TF_hadd_madamc_Tag2   	) ; 
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, " \\hline \n");
       fprintf (outfulltable, "\\end{tabular}\n\n");
       fprintf (outfulltable, "\\end{document}\n\n");
      fclose (outfulltable);

     }


   TString outrootname = "nTaglatex_"+region+"_"+variable+"_"+description;
   TFile *newfile = new TFile(outrootname+".root","recreate");
 h_DY_2016_M50         ->Write(); 
 h_DY_2016_mad_M50     ->Write(); 
 h_DY_2016_madamc_M50     ->Write(); 
 h_DY_2017_M50         ->Write(); 
 h_DY_2018_M50         ->Write(); 
 h_DY_2018_mad_M50     ->Write(); 
 h_DY_2018_madamc_M50     ->Write(); 
 h_DY_2018_M50_JEC     ->Write(); 
 h_DY_2018_mad_M50_JEC ->Write(); 
 //h_DY_2018_madamc_M50_JEC ->Write(); 
 //h_DY_2018_M50_JEC_Zpt ->Write(); 
 h_DY_2018_2J_JEC      ->Write(); 
 h_DY_hadd	       ->Write();
 h_DY_hadd_madamc	       ->Write();
 h_ZH_2016_M50         ->Write(); 
 h_ZH_2016_mad_M50     ->Write(); 
 h_ZH_2016_madamc_M50     ->Write(); 
 h_ZH_2017_M50         ->Write(); 
 h_ZH_2018_M50         ->Write(); 
 h_ZH_2018_mad_M50     ->Write(); 
 h_ZH_2018_madamc_M50     ->Write(); 
 h_ZH_2018_M50_JEC     ->Write(); 
 h_ZH_2018_mad_M50_JEC ->Write(); 
 //h_ZH_2018_madamc_M50_JEC ->Write(); 
 //h_ZH_2018_M50_JEC_Zpt ->Write(); 
 h_ZH_2018_2J_JEC      ->Write(); 
 h_ZH_hadd	       ->Write();
 h_ZH_hadd_madamc	       ->Write();
 h_TF_2016_M50         ->Write(); 
 h_TF_2016_mad_M50     ->Write(); 
 h_TF_2016_madamc_M50     ->Write(); 
 h_TF_2017_M50         ->Write(); 
 h_TF_2018_M50         ->Write(); 
 h_TF_2018_mad_M50     ->Write(); 
 h_TF_2018_madamc_M50     ->Write(); 
 h_TF_2018_M50_JEC     ->Write(); 
 h_TF_2018_mad_M50_JEC ->Write(); 
 //h_TF_2018_madamc_M50_JEC ->Write(); 
 //h_TF_2018_M50_JEC_Zpt ->Write(); 
 h_TF_2018_2J_JEC      ->Write(); 
 h_TF_hadd	       ->Write();
 h_TF_hadd_madamc	       ->Write();




     // Integrals

     
   } 
  }
 } 
